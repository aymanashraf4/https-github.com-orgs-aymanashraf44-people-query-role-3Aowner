$(function()
{

'use strict';

$('#x-x  a').click(function(e)
{
e.preventDefault();

$('html , body').animate({

scrollTop: $('#' + $(this).data('scroll')).offset().top

},1500);

});

});

$(document).ready(function()
{

$(".img-thumbnail-fir").on("click",function()
{
 

$("#main-picc").hide().attr(

    "src" , $(this).attr("src")
).fadeIn(1000)
});


});

$(document).ready(function()
{

$(".img-thumbnail-firr").on("click",function()
{
 

$("#main-picc").hide().attr(

    "src" , $(this).attr("src")
).fadeIn(1000)
});


});


$(document).ready(function()
{

$(".img-thumbnail-firrr").on("click",function()
{
 

$("#main-picc").hide().attr(

    "src" , $(this).attr("src")
).fadeIn(1000)
});


});

$(document).ready(function()
{
$("html").niceScroll();

});



var typed = new Typed('#a-a', {
    strings: ["Ayman Ashraf Mohammed"],
    typeSpeed: 300
    });

    var typed = new Typed('#b-b', {
        strings: ["Web Designer"],
        typeSpeed: 300
        });
    





$(document).ready(function()
{
console.log($("#one-a").offset().top)
});



$(document).ready(function () {
    $(window).scroll(function () {
        if ($(this).scrollTop() >= 2411)
        {
           $("#one-a").animate({

               width:"369px"
            
            },5000,function()
            {

                $("#persent").fadeIn(3000);
            });

           
        }
     
       
    });
 


});


$(document).ready(function () {
    $(window).scroll(function () {
        if ($(this).scrollTop() >= 2411)
        {
           $("#one-x").animate({

               width:"369px"
            
            },5000,function()
            {

                $("#persent-x").fadeIn(3000);
            });

           
        }
     
       
    });
 


});



$(document).ready(function () {
    $(window).scroll(function () {
        if ($(this).scrollTop() >= 2411)
        {
           $("#one-z").animate({

               width:"369px"
            
            },5000,function()
            {

                $("#persent-z").fadeIn(3000);
            });

           
        }
     
       
    });
 


});


$(document).ready(function () {
    $(window).scroll(function () {
        if ($(this).scrollTop() >= 2411)
        {
           $("#one-b").animate({

               width:"330px"
            
            },5000,function()
            {

                $("#persent-b").fadeIn(3000);
            });

           
        }
     
       
    });
 


});



$(document).ready(function () {
    $(window).scroll(function () {
        if ($(this).scrollTop() >= 2411)
        {
           $("#one-d").animate({

               width:"290px"
            
            },5000,function()
            {

                $("#persent-d").fadeIn(3000);
            });

           
        }
     
       
    });
 


});


$(document).ready(function () {
    $(window).scroll(function () {
        if ($(this).scrollTop() >= 2411)
        {
           $("#one-f").animate({

               width:"330px"
            
            },5000,function()
            {

                $("#persent-f").fadeIn(3000);
            });

           
        }
     
       
    });
 


});


$(document).ready(function () {
    $(window).scroll(function () {
        if ($(this).scrollTop() >= 2411)
        {
           $("#one-e").animate({

               width:"220px"
            
            },5000,function()
            {

                $("#persent-e").fadeIn(3000);
            });

           
        }
     
       
    });
 


});


$(document).ready(function () {
    var scrollButton = $(".scroll-top");
    $(window).scroll(function () {
        console.log($(this).scrollTop());
        if ($(this).scrollTop() >= 700)
        {
            scrollButton.show();
        }
        else
        {
            scrollButton.hide();
        }
        /*click on button to scroll top*/
       
    });
    scrollButton.click(function () {

        $("html,body").animate({ scrollTop: 0 }, 600);
    });


});
